
if not res_mt then
	res_mt = {
	}
	res_mt.__index = res_mt

	function res_mt:get(key)
		local message = self.messages[key]
		if message then
			return message
		elseif self.old then
			return self.old.get(key)
		else
			return key
		end
	end
end

res = {
	old = res
}
setmetatable(res, res_mt)

res.messages = {
	booting = "引导中..."
}
