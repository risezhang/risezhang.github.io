local log = require "framework.log"
local apps = require "framework.apps"
local services = require "framework.services"
local ui = require "framework.ui"

function onFronted(object)
	ui.startBusy(nil, res:get("booting"))
	local status = services.hello()
	ui.stopBusy()

	apps.switch("Login")
end

function onDestroy(object)
end

function onCreated(object)
	local ams = registry.getService("appmanagement")
	local frameworkapp = ams:getAppSandbox("framework")
	frameworkapp:eval("if not _onReady_ and onReady then onReady() _onReady_ = true end")
end

function onIdle(object)
end
